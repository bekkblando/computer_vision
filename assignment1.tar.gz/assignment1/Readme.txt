Course id--section no
cpsc482
Bekk Blando
Converts PPM Image File into PGM greyscale
Lessons Learned: Reading in blocks of memory, only works for max color values under 256
Call the program with the PPM location as the first argument and the filename of the PGM as the second argument(include .pgm in the second argument)