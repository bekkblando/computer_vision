cpsc482 - Section 1
Bekk Blando
Create mp4 using opencv and ffmeg
Lessons Learned: Had a bit of trouble with the fade out and getting it to recognize the same faces once they've reentered the video.
Didn't quite get to the results I wanted. Should have started earlier, had job interviews that took a bunch of time.

The first argument is the input filename, the second argument is the output filename 

Install Using:
pipenv install

Run Using:
pipenv run python find_faces.py Test.mov output
